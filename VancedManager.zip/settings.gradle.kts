rootProject.name = "Vanced Manager"

include(":app")
