---
name: Bug issue template
about: Vanced Manager Bug template
title: ''
labels: ''
assignees: ''

---

**Please only open the issue if the following is true**
- This is an issue in the Vanced Manager and ONLY Vanced Manager (NOT Youtube Vanced/Music/microG)

**Phone Specifications:**
- Brand:
- Operating System:
- Android Version:
- Vanced Manager Version:

**Please describe the problem you are having in as much detail as possible:**


**Steps to reproduce:**


**Further details:**
